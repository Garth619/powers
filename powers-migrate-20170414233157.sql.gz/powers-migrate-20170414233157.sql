# WordPress MySQL database migration
#
# Generated: Friday 14. April 2017 23:31 UTC
# Hostname: localhost
# Database: `powers`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=972 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://powers.com', 'yes'),
(2, 'home', 'http://powers.com', 'yes'),
(3, 'blogname', 'Jessica Powers', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1point21interactive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:19:"bugherd/bugherd.php";i:4;s:24:"wordpress-seo/wp-seo.php";i:5;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'powers', 'yes'),
(41, 'stylesheet', 'powers', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:3:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}i:3;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '50', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:3:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}i:3;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:19:"wp_inactive_widgets";a:0:{}s:11:"cat-sidebar";a:1:{i:0;s:12:"categories-3";}s:15:"archive-sidebar";a:1:{i:0;s:10:"archives-3";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:6:{i:1492213000;a:1:{s:25:"wpseo_ping_search_engines";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1492252142;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1492287603;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1492295707;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1492296799;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1489012512;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(117, 'can_compress_scripts', '1', 'no'),
(135, 'current_theme', 'Jessica Powers', 'yes'),
(136, 'theme_mods_powers', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(142, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(196, 'recently_activated', 'a:0:{}', 'yes'),
(207, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(208, 'rg_form_version', '2.1.3', 'yes'),
(211, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(212, 'rg_gforms_disable_css', '1', 'yes'),
(213, 'rg_gforms_enable_html5', '0', 'yes'),
(214, 'gform_enable_noconflict', '0', 'yes'),
(215, 'rg_gforms_enable_akismet', '', 'yes'),
(216, 'rg_gforms_captcha_public_key', '', 'yes'),
(217, 'rg_gforms_captcha_private_key', '', 'yes'),
(218, 'rg_gforms_currency', 'USD', 'yes'),
(219, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(223, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(373, 'WPLANG', '', 'yes'),
(653, 'category_children', 'a:0:{}', 'yes'),
(761, 'bugherd_options', 'a:4:{s:24:"bugherd_integration_code";s:22:"bhotvkeytcxvodpmxvkmcg";s:11:"user_levels";a:1:{i:0;s:12:"unregistered";}s:12:"enable_admin";s:2:"no";s:5:"sites";a:0:{}}', 'yes'),
(773, 'acf_version', '5.5.11', 'yes'),
(774, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNeU9ETjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEEzSURJeE9qSTRPak0yIjtzOjM6InVybCI7czoxNzoiaHR0cDovL3Bvd2Vycy5jb20iO30=', 'yes'),
(775, 'hookturn_acftcp_license_key', 'b3JkZXJfaWQ9MzMyODN8dHlwZT1kZXZlbG9wZXJ8ZGF0ZT0yMDE0LTA3LTA3IDIxOjI4OjM2', 'yes'),
(778, '84526b2d68bbfe9778dd421d1e3c3623', 'a:2:{s:7:"timeout";i:1492216732;s:5:"value";s:132:"{"new_version":"","stable_version":"","sections":"","license_check":"","msg":"License key provided does not match a valid Download"}";}', 'yes'),
(844, 'wpseo', 'a:24:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"4.6";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";b:0;}', 'yes'),
(845, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(846, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:1;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(847, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"9c135a79482fc7342e62b5bb6ef883ee";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(848, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(849, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(850, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(851, 'wpseo_flush_rewrite', '1', 'yes'),
(854, 'wpseo_sitemap_cache_validator_global', '6KZiN', 'no'),
(861, 'wpseo_sitemap_1_cache_validator', '6Y2Ed', 'no'),
(862, 'wpseo_sitemap_page_cache_validator', '6Y2Ef', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=456 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1489013468:1'),
(4, 4, '_wp_page_template', 'page-main.php'),
(12, 8, '_edit_last', '1'),
(13, 8, '_wp_page_template', 'page-caseresults.php'),
(14, 8, '_edit_lock', '1491582433:1'),
(15, 10, '_edit_last', '1'),
(16, 10, '_wp_page_template', 'page-testimonials.php'),
(17, 10, '_edit_lock', '1491599079:1'),
(57, 18, '_menu_item_type', 'post_type'),
(58, 18, '_menu_item_menu_item_parent', '0'),
(59, 18, '_menu_item_object_id', '4'),
(60, 18, '_menu_item_object', 'page'),
(61, 18, '_menu_item_target', ''),
(62, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(63, 18, '_menu_item_xfn', ''),
(64, 18, '_menu_item_url', ''),
(66, 19, '_menu_item_type', 'post_type'),
(67, 19, '_menu_item_menu_item_parent', '0'),
(68, 19, '_menu_item_object_id', '8'),
(69, 19, '_menu_item_object', 'page'),
(70, 19, '_menu_item_target', ''),
(71, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(72, 19, '_menu_item_xfn', ''),
(73, 19, '_menu_item_url', ''),
(75, 20, '_menu_item_type', 'post_type'),
(76, 20, '_menu_item_menu_item_parent', '0'),
(77, 20, '_menu_item_object_id', '10'),
(78, 20, '_menu_item_object', 'page'),
(79, 20, '_menu_item_target', ''),
(80, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(81, 20, '_menu_item_xfn', ''),
(82, 20, '_menu_item_url', ''),
(84, 21, '_menu_item_type', 'custom'),
(85, 21, '_menu_item_menu_item_parent', '0'),
(86, 21, '_menu_item_object_id', '21'),
(87, 21, '_menu_item_object', 'custom'),
(88, 21, '_menu_item_target', ''),
(89, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(90, 21, '_menu_item_xfn', ''),
(91, 21, '_menu_item_url', ''),
(93, 22, '_menu_item_type', 'custom'),
(94, 22, '_menu_item_menu_item_parent', '0'),
(95, 22, '_menu_item_object_id', '22'),
(96, 22, '_menu_item_object', 'custom'),
(97, 22, '_menu_item_target', ''),
(98, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(99, 22, '_menu_item_xfn', ''),
(100, 22, '_menu_item_url', ''),
(102, 23, '_edit_last', '1'),
(103, 23, '_edit_lock', '1491333467:1'),
(104, 23, '_wp_page_template', 'page-contact.php'),
(105, 25, '_menu_item_type', 'post_type'),
(106, 25, '_menu_item_menu_item_parent', '0'),
(107, 25, '_menu_item_object_id', '23'),
(108, 25, '_menu_item_object', 'page'),
(109, 25, '_menu_item_target', ''),
(110, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 25, '_menu_item_xfn', ''),
(112, 25, '_menu_item_url', ''),
(155, 36, '_edit_last', '1'),
(156, 36, '_edit_lock', '1492208505:1'),
(157, 36, '_wp_page_template', 'page-about.php'),
(158, 38, '_menu_item_type', 'post_type'),
(159, 38, '_menu_item_menu_item_parent', '21'),
(160, 38, '_menu_item_object_id', '36'),
(161, 38, '_menu_item_object', 'page'),
(162, 38, '_menu_item_target', ''),
(163, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(164, 38, '_menu_item_xfn', ''),
(165, 38, '_menu_item_url', ''),
(175, 39, '_edit_last', '1'),
(176, 39, '_edit_lock', '1491324871:1'),
(177, 39, '_wp_page_template', 'page-practiceareas.php'),
(178, 41, '_menu_item_type', 'post_type'),
(179, 41, '_menu_item_menu_item_parent', '22'),
(180, 41, '_menu_item_object_id', '39'),
(181, 41, '_menu_item_object', 'page'),
(182, 41, '_menu_item_target', ''),
(183, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(184, 41, '_menu_item_xfn', ''),
(185, 41, '_menu_item_url', ''),
(187, 42, '_edit_last', '1'),
(188, 42, '_edit_lock', '1491413636:1'),
(189, 43, '_edit_last', '1'),
(190, 43, '_edit_lock', '1492209480:1'),
(191, 43, '_wp_page_template', 'page-bio.php'),
(192, 45, '_menu_item_type', 'post_type'),
(193, 45, '_menu_item_menu_item_parent', '21'),
(194, 45, '_menu_item_object_id', '43'),
(195, 45, '_menu_item_object', 'page'),
(196, 45, '_menu_item_target', ''),
(197, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(198, 45, '_menu_item_xfn', ''),
(199, 45, '_menu_item_url', ''),
(201, 46, '_edit_last', '1'),
(202, 46, '_edit_lock', '1492206833:1'),
(203, 46, '_wp_page_template', 'default'),
(204, 48, '_menu_item_type', 'post_type'),
(205, 48, '_menu_item_menu_item_parent', '22') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(206, 48, '_menu_item_object_id', '46'),
(207, 48, '_menu_item_object', 'page'),
(208, 48, '_menu_item_target', ''),
(209, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(210, 48, '_menu_item_xfn', ''),
(211, 48, '_menu_item_url', ''),
(213, 50, '_edit_last', '1'),
(214, 50, '_edit_lock', '1491859030:1'),
(215, 50, '_wp_page_template', 'page-blog.php'),
(216, 52, '_menu_item_type', 'post_type'),
(217, 52, '_menu_item_menu_item_parent', '21'),
(218, 52, '_menu_item_object_id', '50'),
(219, 52, '_menu_item_object', 'page'),
(220, 52, '_menu_item_target', ''),
(221, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(222, 52, '_menu_item_xfn', ''),
(223, 52, '_menu_item_url', ''),
(225, 54, '_edit_last', '1'),
(226, 54, '_edit_lock', '1491856513:1'),
(229, 54, '_wp_old_slug', 'test'),
(232, 42, '_wp_desired_post_slug', ''),
(234, 58, '_edit_last', '1'),
(235, 58, '_edit_lock', '1491856510:1'),
(237, 60, '_edit_last', '1'),
(238, 60, '_edit_lock', '1491856505:1'),
(256, 60, '_wp_old_slug', 'blog-title-goes-here-2__trashed'),
(258, 58, '_wp_old_slug', 'blog-title-goes-here__trashed'),
(260, 54, '_wp_old_slug', 'blog-post-title-here__trashed'),
(261, 67, '_edit_last', '1'),
(262, 67, '_edit_lock', '1492210627:1'),
(263, 67, '_wp_page_template', 'page-videocenter.php'),
(264, 69, '_menu_item_type', 'post_type'),
(265, 69, '_menu_item_menu_item_parent', '21'),
(266, 69, '_menu_item_object_id', '67'),
(267, 69, '_menu_item_object', 'page'),
(268, 69, '_menu_item_target', ''),
(269, 69, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(270, 69, '_menu_item_xfn', ''),
(271, 69, '_menu_item_url', ''),
(274, 80, '_edit_last', '1'),
(275, 80, '_edit_lock', '1492208860:1'),
(276, 82, '_wp_attached_file', '2017/04/about.jpeg'),
(277, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:590;s:4:"file";s:18:"2017/04/about.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"about-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"about-254x300.jpeg";s:5:"width";i:254;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"about-500x198.jpeg";s:5:"width";i:500;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(278, 36, 'about_us_image', '82'),
(279, 36, '_about_us_image', 'field_58f146375dcc5'),
(280, 83, 'about_us_image', '82'),
(281, 83, '_about_us_image', 'field_58f146375dcc5'),
(282, 84, 'about_us_image', '82'),
(283, 84, '_about_us_image', 'field_58f146375dcc5'),
(284, 36, 'yst_is_cornerstone', ''),
(285, 36, 'about_quote', 'Lorem ipsum <span class="green">dolor sit amet</span>, consect adipiscing elit. Quisque luctus, dolor a convallis efficitur odio ante solli cit udin&nbsp;ipsum.'),
(286, 36, '_about_quote', 'field_58f147d650fe4'),
(287, 86, 'about_us_image', '82'),
(288, 86, '_about_us_image', 'field_58f146375dcc5'),
(289, 86, 'about_quote', 'Lorem ipsum <span class="green">dolor sit amet</span>, consect adipiscing elit. Quisque luctus, dolor a convallis efficitur odio ante solli cit udin&nbsp;ipsum.'),
(290, 86, '_about_quote', 'field_58f147d650fe4'),
(291, 87, 'yst_is_cornerstone', ''),
(292, 80, 'yst_is_cornerstone', ''),
(293, 36, '_yoast_wpseo_content_score', '60'),
(294, 36, 'about_quote_title', 'Powers Injury Law'),
(295, 36, '_about_quote_title', 'field_58f1489f0530d'),
(296, 88, 'about_us_image', '82'),
(297, 88, '_about_us_image', 'field_58f146375dcc5'),
(298, 88, 'about_quote', 'Lorem ipsum <span class="green">dolor sit amet</span>, consect adipiscing elit. Quisque luctus, dolor a convallis efficitur odio ante solli cit udin&nbsp;ipsum.'),
(299, 88, '_about_quote', 'field_58f147d650fe4'),
(300, 88, 'about_quote_title', 'Powers Injury&nbsp;Law'),
(301, 88, '_about_quote_title', 'field_58f1489f0530d'),
(302, 89, 'yst_is_cornerstone', ''),
(303, 90, 'yst_is_cornerstone', ''),
(304, 36, 'meet_jessica_powers_button', 'Meet Jessica Powers'),
(305, 36, '_meet_jessica_powers_button', 'field_58f1493bed94c'),
(306, 36, 'meet_page_link', '43'),
(307, 36, '_meet_page_link', 'field_58f14948fea0a'),
(308, 91, 'about_us_image', '82'),
(309, 91, '_about_us_image', 'field_58f146375dcc5'),
(310, 91, 'about_quote', 'Lorem ipsum <span class="green">dolor sit amet</span>, consect adipiscing elit. Quisque luctus, dolor a convallis efficitur odio ante solli cit udin&nbsp;ipsum.'),
(311, 91, '_about_quote', 'field_58f147d650fe4'),
(312, 91, 'about_quote_title', 'Powers Injury Law'),
(313, 91, '_about_quote_title', 'field_58f1489f0530d'),
(314, 91, 'meet_jessica_powers_button', 'Meet Jessica Powers'),
(315, 91, '_meet_jessica_powers_button', 'field_58f1493bed94c'),
(316, 91, 'meet_page_link', '43'),
(317, 91, '_meet_page_link', 'field_58f14948fea0a'),
(318, 92, 'yst_is_cornerstone', ''),
(319, 92, '_edit_last', '1'),
(320, 93, 'yst_is_cornerstone', ''),
(321, 92, '_edit_lock', '1492209492:1'),
(322, 81, 'yst_is_cornerstone', ''),
(323, 94, '_wp_attached_file', '2017/04/profile-powers.jpeg'),
(324, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:430;s:4:"file";s:27:"2017/04/profile-powers.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"profile-powers-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"profile-powers-251x300.jpeg";s:5:"width";i:251;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"profile-powers-360x198.jpeg";s:5:"width";i:360;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(325, 43, 'yst_is_cornerstone', ''),
(326, 43, '_yoast_wpseo_content_score', '30'),
(327, 43, 'meet_our_attorney_image', '94'),
(328, 43, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(329, 95, 'meet_our_attorney_image', '94'),
(330, 95, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(331, 96, 'yst_is_cornerstone', ''),
(332, 43, 'meet_attorney_title', 'Attorney Jessica Powers'),
(333, 43, '_meet_attorney_title', 'field_58f14e1a7abb7'),
(334, 97, 'meet_our_attorney_image', '94') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(335, 97, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(336, 97, 'meet_attorney_title', 'Attorney Jessica&nbsp;Powers'),
(337, 97, '_meet_attorney_title', 'field_58f14e1a7abb7'),
(338, 98, 'yst_is_cornerstone', ''),
(339, 43, 'meet_attorney_quote', '<span class="green">I advocate</span> on behalf of individuals, <span class="green">for all people...to provide them a voice</span> in a very loud and confusing system.'),
(340, 43, '_meet_attorney_quote', 'field_58f14e5735c85'),
(341, 99, 'meet_our_attorney_image', '94'),
(342, 99, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(343, 99, 'meet_attorney_title', 'Attorney Jessica Powers'),
(344, 99, '_meet_attorney_title', 'field_58f14e1a7abb7'),
(345, 99, 'meet_attorney_quote', '<span class="green">I advocate</span> on behalf of individuals, <span class="green">for all people...to provide them a voice</span> in a very loud and confusing system.'),
(346, 99, '_meet_attorney_quote', 'field_58f14e5735c85'),
(347, 100, 'yst_is_cornerstone', ''),
(348, 101, 'yst_is_cornerstone', ''),
(349, 43, 'column_1', '<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n\r\n				<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2> \r\n<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>'),
(350, 43, '_column_1', 'field_58f14f07db597'),
(351, 43, 'column_2', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\n\r\n				<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n				\r\n				<p>ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>'),
(352, 43, '_column_2', 'field_58f14f1edb598'),
(353, 102, 'meet_our_attorney_image', '94'),
(354, 102, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(355, 102, 'meet_attorney_title', 'Attorney Jessica Powers'),
(356, 102, '_meet_attorney_title', 'field_58f14e1a7abb7'),
(357, 102, 'meet_attorney_quote', '<span class="green">I advocate</span> on behalf of individuals, <span class="green">for all people...to provide them a voice</span> in a very loud and confusing system.'),
(358, 102, '_meet_attorney_quote', 'field_58f14e5735c85'),
(359, 102, 'column_1', '<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n\r\n				<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2> \r\n<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>'),
(360, 102, '_column_1', 'field_58f14f07db597'),
(361, 102, 'column_2', ''),
(362, 102, '_column_2', 'field_58f14f1edb598'),
(363, 103, 'meet_our_attorney_image', '94'),
(364, 103, '_meet_our_attorney_image', 'field_58f14cac18e74'),
(365, 103, 'meet_attorney_title', 'Attorney Jessica Powers'),
(366, 103, '_meet_attorney_title', 'field_58f14e1a7abb7'),
(367, 103, 'meet_attorney_quote', '<span class="green">I advocate</span> on behalf of individuals, <span class="green">for all people...to provide them a voice</span> in a very loud and confusing system.'),
(368, 103, '_meet_attorney_quote', 'field_58f14e5735c85'),
(369, 103, 'column_1', '<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n\r\n				<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2> \r\n<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>'),
(370, 103, '_column_1', 'field_58f14f07db597'),
(371, 103, 'column_2', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\n\r\n				<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n				\r\n				<p>ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>'),
(372, 103, '_column_2', 'field_58f14f1edb598'),
(373, 104, 'yst_is_cornerstone', ''),
(374, 104, '_edit_last', '1'),
(375, 105, 'yst_is_cornerstone', ''),
(376, 106, 'yst_is_cornerstone', ''),
(377, 107, 'yst_is_cornerstone', ''),
(378, 104, '_edit_lock', '1492210992:1'),
(379, 67, 'yst_is_cornerstone', ''),
(380, 67, '_yoast_wpseo_content_score', '30'),
(381, 67, 'video_0_wistis_code', '<script src="https://fast.wistia.com/embed/medias/v2q97a6dh4.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_v2q97a6dh4 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>\r\n'),
(382, 67, '_video_0_wistis_code', 'field_58f14ff71181d'),
(383, 67, 'video_0_video_title', 'Firm Overview'),
(384, 67, '_video_0_video_title', 'field_58f150241181e'),
(385, 67, 'video_1_wistis_code', '<script src="https://fast.wistia.com/embed/medias/7vphf52t5a.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_7vphf52t5a popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(386, 67, '_video_1_wistis_code', 'field_58f14ff71181d'),
(387, 67, 'video_1_video_title', 'Worker\'s Compensation'),
(388, 67, '_video_1_video_title', 'field_58f150241181e'),
(389, 67, 'video', '7'),
(390, 67, '_video', 'field_58f14feb1181c'),
(391, 108, 'video_0_wistis_code', '<script src="https://fast.wistia.com/embed/medias/v2q97a6dh4.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_v2q97a6dh4 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>\r\n'),
(392, 108, '_video_0_wistis_code', 'field_58f14ff71181d'),
(393, 108, 'video_0_video_title', 'Firm Overview'),
(394, 108, '_video_0_video_title', 'field_58f150241181e'),
(395, 108, 'video_1_wistis_code', '<script src="https://fast.wistia.com/embed/medias/7vphf52t5a.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_7vphf52t5a popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(396, 108, '_video_1_wistis_code', 'field_58f14ff71181d'),
(397, 108, 'video_1_video_title', 'Worker\'s Compensation'),
(398, 108, '_video_1_video_title', 'field_58f150241181e'),
(399, 108, 'video', '2'),
(400, 108, '_video', 'field_58f14feb1181c'),
(401, 67, 'video_2_wistis_code', '<script src="https://fast.wistia.com/embed/medias/v2q97a6dh4.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_v2q97a6dh4 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(402, 67, '_video_2_wistis_code', 'field_58f14ff71181d'),
(403, 67, 'video_2_video_title', 'Premises Liability'),
(404, 67, '_video_2_video_title', 'field_58f150241181e'),
(405, 67, 'video_3_wistis_code', '<script src="https://fast.wistia.com/embed/medias/kwpxqk4lv1.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_kwpxqk4lv1 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>\r\n'),
(406, 67, '_video_3_wistis_code', 'field_58f14ff71181d'),
(407, 67, 'video_3_video_title', 'Truck Accidents'),
(408, 67, '_video_3_video_title', 'field_58f150241181e'),
(409, 67, 'video_4_wistis_code', '<script src="https://fast.wistia.com/embed/medias/ufvs667ynw.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_ufvs667ynw popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(410, 67, '_video_4_wistis_code', 'field_58f14ff71181d'),
(411, 67, 'video_4_video_title', 'Wrongful Death'),
(412, 67, '_video_4_video_title', 'field_58f150241181e'),
(413, 67, 'video_5_wistis_code', '<script src="https://fast.wistia.com/embed/medias/w15tmuka1i.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_w15tmuka1i popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(414, 67, '_video_5_wistis_code', 'field_58f14ff71181d'),
(415, 67, 'video_5_video_title', 'Distracted Driving'),
(416, 67, '_video_5_video_title', 'field_58f150241181e'),
(417, 67, 'video_6_wistis_code', '<script src="https://fast.wistia.com/embed/medias/sxi3o4n4ur.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_sxi3o4n4ur popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(418, 67, '_video_6_wistis_code', 'field_58f14ff71181d'),
(419, 67, 'video_6_video_title', 'Car Accidents'),
(420, 67, '_video_6_video_title', 'field_58f150241181e'),
(421, 109, 'video_0_wistis_code', '<script src="https://fast.wistia.com/embed/medias/v2q97a6dh4.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_v2q97a6dh4 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>\r\n'),
(422, 109, '_video_0_wistis_code', 'field_58f14ff71181d'),
(423, 109, 'video_0_video_title', 'Firm Overview'),
(424, 109, '_video_0_video_title', 'field_58f150241181e'),
(425, 109, 'video_1_wistis_code', '<script src="https://fast.wistia.com/embed/medias/7vphf52t5a.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_7vphf52t5a popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(426, 109, '_video_1_wistis_code', 'field_58f14ff71181d'),
(427, 109, 'video_1_video_title', 'Worker\'s Compensation'),
(428, 109, '_video_1_video_title', 'field_58f150241181e'),
(429, 109, 'video', '7'),
(430, 109, '_video', 'field_58f14feb1181c'),
(431, 109, 'video_2_wistis_code', '<script src="https://fast.wistia.com/embed/medias/v2q97a6dh4.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_v2q97a6dh4 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(432, 109, '_video_2_wistis_code', 'field_58f14ff71181d'),
(433, 109, 'video_2_video_title', 'Premises Liability'),
(434, 109, '_video_2_video_title', 'field_58f150241181e') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(435, 109, 'video_3_wistis_code', '<script src="https://fast.wistia.com/embed/medias/kwpxqk4lv1.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_kwpxqk4lv1 popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>\r\n'),
(436, 109, '_video_3_wistis_code', 'field_58f14ff71181d'),
(437, 109, 'video_3_video_title', 'Truck Accidents'),
(438, 109, '_video_3_video_title', 'field_58f150241181e'),
(439, 109, 'video_4_wistis_code', '<script src="https://fast.wistia.com/embed/medias/ufvs667ynw.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_ufvs667ynw popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(440, 109, '_video_4_wistis_code', 'field_58f14ff71181d'),
(441, 109, 'video_4_video_title', 'Wrongful Death'),
(442, 109, '_video_4_video_title', 'field_58f150241181e'),
(443, 109, 'video_5_wistis_code', '<script src="https://fast.wistia.com/embed/medias/w15tmuka1i.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_w15tmuka1i popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(444, 109, '_video_5_wistis_code', 'field_58f14ff71181d'),
(445, 109, 'video_5_video_title', 'Distracted Driving'),
(446, 109, '_video_5_video_title', 'field_58f150241181e'),
(447, 109, 'video_6_wistis_code', '<script src="https://fast.wistia.com/embed/medias/sxi3o4n4ur.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><span class="wistia_embed wistia_async_sxi3o4n4ur popover=true popoverAnimateThumbnail=true videoFoam=true" style="display:inline-block;height:100%;width:100%">&nbsp;</span></div></div>'),
(448, 109, '_video_6_wistis_code', 'field_58f14ff71181d'),
(449, 109, 'video_6_video_title', 'Car Accidents'),
(450, 109, '_video_6_video_title', 'field_58f150241181e'),
(451, 110, 'yst_is_cornerstone', ''),
(452, 110, '_edit_last', '1'),
(453, 111, 'yst_is_cornerstone', ''),
(454, 112, 'yst_is_cornerstone', ''),
(455, 110, '_edit_lock', '1492212566:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-03-08 22:53:29', '2017-03-08 22:53:29', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-03-08 22:53:29', '2017-03-08 22:53:29', '', 0, 'http://powers.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2017-03-08 22:53:29', '2017-03-08 22:53:29', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-03-08 22:53:29', '2017-03-08 22:53:29', '', 4, 'http://powers.com/2017/03/08/4-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2017-03-08 23:50:05', '2017-03-08 23:50:05', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2017-04-07 16:29:34', '2017-04-07 16:29:34', '', 0, 'http://powers.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-03-08 23:50:05', '2017-03-08 23:50:05', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-08 23:50:05', '2017-03-08 23:50:05', '', 8, 'http://powers.com/2017/03/08/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2017-03-08 23:50:16', '2017-03-08 23:50:16', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2017-04-07 21:06:59', '2017-04-07 21:06:59', '', 0, 'http://powers.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-03-08 23:50:16', '2017-03-08 23:50:16', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-03-08 23:50:16', '2017-03-08 23:50:16', '', 10, 'http://powers.com/2017/03/08/10-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2017-03-08 23:51:22', '2017-03-08 23:51:22', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2017-03-08 23:51:22', '2017-03-08 23:51:22', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=19', 10, 'nav_menu_item', '', 0),
(20, 1, '2017-03-08 23:51:22', '2017-03-08 23:51:22', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=20', 11, 'nav_menu_item', '', 0),
(21, 1, '2017-03-08 23:51:22', '2017-03-08 23:51:22', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=21', 2, 'nav_menu_item', '', 0),
(22, 1, '2017-03-08 23:51:54', '2017-03-08 23:51:54', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=22', 7, 'nav_menu_item', '', 0),
(23, 1, '2017-03-09 21:41:58', '2017-03-09 21:41:58', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-04-04 19:19:45', '2017-04-04 19:19:45', '', 0, 'http://powers.com/?page_id=23', 0, 'page', '', 0),
(24, 1, '2017-03-09 21:41:58', '2017-03-09 21:41:58', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-03-09 21:41:58', '2017-03-09 21:41:58', '', 23, 'http://powers.com/2017/03/09/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-03-09 21:42:08', '2017-03-09 21:42:08', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=25', 12, 'nav_menu_item', '', 0),
(36, 1, '2017-04-03 17:57:47', '2017-04-03 17:57:47', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nNeque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'About Our Law&nbsp;Firm', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2017-04-14 22:23:10', '2017-04-14 22:23:10', '', 0, 'http://powers.com/?page_id=36', 0, 'page', '', 0),
(37, 1, '2017-04-03 17:57:47', '2017-04-03 17:57:47', '', 'About', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-03 17:57:47', '2017-04-03 17:57:47', '', 36, 'http://powers.com/2017/04/03/36-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2017-04-03 17:58:42', '2017-04-03 17:58:42', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=38', 3, 'nav_menu_item', '', 0),
(39, 1, '2017-04-04 16:56:50', '2017-04-04 16:56:50', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2017-04-04 16:56:50', '2017-04-04 16:56:50', '', 0, 'http://powers.com/?page_id=39', 0, 'page', '', 0),
(40, 1, '2017-04-04 16:56:50', '2017-04-04 16:56:50', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2017-04-04 16:56:50', '2017-04-04 16:56:50', '', 39, 'http://powers.com/2017/04/04/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2017-04-04 17:08:19', '2017-04-04 17:08:19', '', 'View All +', '', 'publish', 'closed', 'closed', '', 'view-all', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=41', 9, 'nav_menu_item', '', 0),
(42, 1, '2017-04-05 17:33:56', '2017-04-05 17:33:56', '', 'Meet Jessica Powers', '', 'draft', 'open', 'open', '', '__trashed', '', '', '2017-04-10 20:46:21', '2017-04-10 20:46:21', '', 0, 'http://powers.com/?p=42', 0, 'post', '', 0),
(43, 1, '2017-04-05 17:34:34', '2017-04-05 17:34:34', '', 'Meet Our Attorney', '', 'publish', 'closed', 'closed', '', 'meet-our-attorney', '', '', '2017-04-14 22:39:01', '2017-04-14 22:39:01', '', 0, 'http://powers.com/?page_id=43', 0, 'page', '', 0),
(44, 1, '2017-04-05 17:34:34', '2017-04-05 17:34:34', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-05 17:34:34', '2017-04-05 17:34:34', '', 43, 'http://powers.com/2017/04/05/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2017-04-05 17:36:09', '2017-04-05 17:36:09', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=45', 4, 'nav_menu_item', '', 0),
(46, 1, '2017-04-05 23:12:36', '2017-04-05 23:12:36', 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2017-04-14 21:56:02', '2017-04-14 21:56:02', '', 0, 'http://powers.com/?page_id=46', 0, 'page', '', 0),
(47, 1, '2017-04-05 23:12:36', '2017-04-05 23:12:36', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-05 23:12:36', '2017-04-05 23:12:36', '', 46, 'http://powers.com/2017/04/05/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2017-04-06 15:59:16', '2017-04-06 15:59:16', ' ', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=48', 8, 'nav_menu_item', '', 0),
(49, 1, '2017-04-10 02:29:07', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-04-10 02:29:07', '0000-00-00 00:00:00', '', 0, 'http://powers.com/?p=49', 0, 'post', '', 0),
(50, 1, '2017-04-10 03:39:58', '2017-04-10 03:39:58', '', 'Personal Injury Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-04-10 21:14:55', '2017-04-10 21:14:55', '', 0, 'http://powers.com/?page_id=50', 0, 'page', '', 0),
(51, 1, '2017-04-10 03:39:58', '2017-04-10 03:39:58', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 03:39:58', '2017-04-10 03:39:58', '', 50, 'http://powers.com/2017/04/10/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2017-04-10 03:40:56', '2017-04-10 03:40:56', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=52', 5, 'nav_menu_item', '', 0),
(53, 1, '2017-04-10 03:43:13', '2017-04-10 03:43:13', '', 'Personal Injury Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 03:43:13', '2017-04-10 03:43:13', '', 50, 'http://powers.com/2017/04/10/50-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2017-04-10 03:48:53', '2017-04-10 03:48:53', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Post Title Here', '', 'publish', 'open', 'open', '', 'blog-post-title-here', '', '', '2017-04-10 20:46:21', '2017-04-10 20:46:21', '', 0, 'http://powers.com/?p=54', 0, 'post', '', 0),
(55, 1, '2017-04-10 03:48:53', '2017-04-10 03:48:53', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Test', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2017-04-10 03:48:53', '2017-04-10 03:48:53', '', 54, 'http://powers.com/2017/04/10/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-04-10 04:21:47', '2017-04-10 04:21:47', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Post Title Here', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2017-04-10 04:21:47', '2017-04-10 04:21:47', '', 54, 'http://powers.com/2017/04/10/54-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2017-04-10 04:39:01', '2017-04-10 04:39:01', '', 'Meet Jessica Powers', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2017-04-10 04:39:01', '2017-04-10 04:39:01', '', 42, 'http://powers.com/2017/04/10/42-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-04-10 16:57:25', '2017-04-10 16:57:25', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Title Goes Here', '', 'publish', 'open', 'open', '', 'blog-title-goes-here', '', '', '2017-04-10 20:46:20', '2017-04-10 20:46:20', '', 0, 'http://powers.com/?p=58', 0, 'post', '', 0),
(59, 1, '2017-04-10 16:57:25', '2017-04-10 16:57:25', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Title Goes Here', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-10 16:57:25', '2017-04-10 16:57:25', '', 58, 'http://powers.com/2017/04/10/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-04-10 16:58:23', '2017-04-10 16:58:23', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Title Goes Here', '', 'publish', 'open', 'open', '', 'blog-title-goes-here-2', '', '', '2017-04-10 20:46:20', '2017-04-10 20:46:20', '', 0, 'http://powers.com/?p=60', 0, 'post', '', 0),
(61, 1, '2017-04-10 16:58:23', '2017-04-10 16:58:23', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Title Goes Here', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2017-04-10 16:58:23', '2017-04-10 16:58:23', '', 60, 'http://powers.com/2017/04/10/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-04-10 20:30:32', '2017-04-10 20:30:32', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Blog Title Goes Here', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2017-04-10 20:30:32', '2017-04-10 20:30:32', '', 60, 'http://powers.com/60-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2017-04-10 21:13:28', '2017-04-10 21:13:28', '', 'Birmingham Personal Injury Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 21:13:28', '2017-04-10 21:13:28', '', 50, 'http://powers.com/50-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2017-04-10 21:14:16', '2017-04-10 21:14:16', '', 'Birmingham Personal Injury&nbsp;Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 21:14:16', '2017-04-10 21:14:16', '', 50, 'http://powers.com/50-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-04-10 21:14:28', '2017-04-10 21:14:28', '', 'Birmingham Personal Injury Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 21:14:28', '2017-04-10 21:14:28', '', 50, 'http://powers.com/50-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2017-04-10 21:14:55', '2017-04-10 21:14:55', '', 'Personal Injury Blog', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-04-10 21:14:55', '2017-04-10 21:14:55', '', 50, 'http://powers.com/50-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2017-04-10 21:19:45', '2017-04-10 21:19:45', '', 'Video Center', '', 'publish', 'closed', 'closed', '', 'video-center', '', '', '2017-04-14 22:57:07', '2017-04-14 22:57:07', '', 0, 'http://powers.com/?page_id=67', 0, 'page', '', 0),
(68, 1, '2017-04-10 21:19:45', '2017-04-10 21:19:45', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2017-04-10 21:19:45', '2017-04-10 21:19:45', '', 67, 'http://powers.com/67-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2017-04-10 21:20:08', '2017-04-10 21:20:08', ' ', '', '', 'publish', 'closed', 'closed', '', '69', '', '', '2017-04-10 21:20:08', '2017-04-10 21:20:08', '', 0, 'http://powers.com/?p=69', 6, 'nav_menu_item', '', 0),
(70, 1, '2017-04-14 21:43:18', '2017-04-14 21:43:18', 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:43:18', '2017-04-14 21:43:18', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2017-04-14 21:48:55', '2017-04-14 21:48:55', '<img class="size-full wp-image-71 alignleft" src="http://powers.com/wp-content/uploads/2017/04/Screen-Shot-2017-04-01-at-4.14.58-PM.png" alt="" width="1256" height="1094" />Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:48:55', '2017-04-14 21:48:55', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2017-04-14 21:51:01', '2017-04-14 21:51:01', '<img class="alignnone wp-image-71 size-full" src="http://powers.com/wp-content/uploads/2017/04/Screen-Shot-2017-04-01-at-4.14.58-PM.png" alt="" width="1256" height="1094" />Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:51:01', '2017-04-14 21:51:01', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2017-04-14 21:51:45', '2017-04-14 21:51:45', '<img class="alignleft wp-image-71 size-medium" src="http://powers.com/wp-content/uploads/2017/04/Screen-Shot-2017-04-01-at-4.14.58-PM-300x261.png" alt="" width="300" height="261" />Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:51:45', '2017-04-14 21:51:45', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-04-14 21:52:06', '2017-04-14 21:52:06', '<img class="wp-image-71 size-medium aligncenter" src="http://powers.com/wp-content/uploads/2017/04/Screen-Shot-2017-04-01-at-4.14.58-PM-300x261.png" alt="" width="300" height="261" />Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:52:06', '2017-04-14 21:52:06', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2017-04-14 21:52:17', '2017-04-14 21:52:17', '<img class="wp-image-71 size-medium alignright" src="http://powers.com/wp-content/uploads/2017/04/Screen-Shot-2017-04-01-at-4.14.58-PM-300x261.png" alt="" width="300" height="261" />Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:52:17', '2017-04-14 21:52:17', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2017-04-14 21:56:02', '2017-04-14 21:56:02', 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a>Embedded link style</a> cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h3>Heading Style 3 - Nemo enim ipsam voluptatem</h3>\r\nNemo enim ipsam voluptatem quia voluptas sit aspernatur autodit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, se consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n 	<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>\r\n</ul>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2017-04-14 21:56:02', '2017-04-14 21:56:02', '', 46, 'http://powers.com/46-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2017-04-14 21:57:24', '2017-04-14 21:57:24', '', 'About Our Law Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 21:57:24', '2017-04-14 21:57:24', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2017-04-14 21:57:55', '2017-04-14 21:57:55', '', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 21:57:55', '2017-04-14 21:57:55', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2017-04-14 22:02:06', '2017-04-14 22:02:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-about.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'About Us', 'about-us', 'publish', 'closed', 'closed', '', 'group_58f14631725e9', '', '', '2017-04-14 22:29:57', '2017-04-14 22:29:57', '', 0, 'http://powers.com/?post_type=acf-field-group&#038;p=80', 0, 'acf-field-group', '', 0),
(81, 1, '2017-04-14 22:02:06', '2017-04-14 22:02:06', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:35:"Image must 500px by 595px and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:495;s:10:"min_height";i:585;s:8:"min_size";s:0:"";s:9:"max_width";i:505;s:10:"max_height";i:595;s:8:"max_size";s:0:"";s:10:"mime_types";s:9:"jpg, jpeg";}', 'About Us Image', 'about_us_image', 'publish', 'closed', 'closed', '', 'field_58f146375dcc5', '', '', '2017-04-14 22:29:57', '2017-04-14 22:29:57', '', 80, 'http://powers.com/?post_type=acf-field&#038;p=81', 0, 'acf-field', '', 0),
(82, 1, '2017-04-14 22:04:04', '2017-04-14 22:04:04', '', 'about', '', 'inherit', 'open', 'closed', '', 'about-2', '', '', '2017-04-14 22:04:04', '2017-04-14 22:04:04', '', 36, 'http://powers.com/wp-content/uploads/2017/04/about.jpeg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2017-04-14 22:04:09', '2017-04-14 22:04:09', '', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 22:04:09', '2017-04-14 22:04:09', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2017-04-14 22:05:49', '2017-04-14 22:05:49', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nNeque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 22:05:49', '2017-04-14 22:05:49', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-04-14 22:06:42', '2017-04-14 22:06:42', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'About Quote', 'about_quote', 'publish', 'closed', 'closed', '', 'field_58f147d650fe4', '', '', '2017-04-14 22:06:42', '2017-04-14 22:06:42', '', 80, 'http://powers.com/?post_type=acf-field&p=85', 1, 'acf-field', '', 0),
(86, 1, '2017-04-14 22:08:51', '2017-04-14 22:08:51', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nNeque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 22:08:51', '2017-04-14 22:08:51', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-04-14 22:09:44', '2017-04-14 22:09:44', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'About Quote Title', 'about_quote_title', 'publish', 'closed', 'closed', '', 'field_58f1489f0530d', '', '', '2017-04-14 22:09:44', '2017-04-14 22:09:44', '', 80, 'http://powers.com/?post_type=acf-field&p=87', 2, 'acf-field', '', 0),
(88, 1, '2017-04-14 22:10:24', '2017-04-14 22:10:24', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nNeque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 22:10:24', '2017-04-14 22:10:24', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2017-04-14 22:12:20', '2017-04-14 22:12:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Meet Jessica Powers Button', 'meet_jessica_powers_button', 'publish', 'closed', 'closed', '', 'field_58f1493bed94c', '', '', '2017-04-14 22:12:20', '2017-04-14 22:12:20', '', 80, 'http://powers.com/?post_type=acf-field&p=89', 3, 'acf-field', '', 0),
(90, 1, '2017-04-14 22:16:22', '2017-04-14 22:16:22', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Meet Page Link', 'meet_page_link', 'publish', 'closed', 'closed', '', 'field_58f14948fea0a', '', '', '2017-04-14 22:16:57', '2017-04-14 22:16:57', '', 80, 'http://powers.com/?post_type=acf-field&#038;p=90', 4, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(91, 1, '2017-04-14 22:23:10', '2017-04-14 22:23:10', '<h2>Heading style 2 - Nemo enim ipsam voluptatem</h2>\r\nNeque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'About Our Law&nbsp;Firm', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-04-14 22:23:10', '2017-04-14 22:23:10', '', 36, 'http://powers.com/36-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2017-04-14 22:28:50', '2017-04-14 22:28:50', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"page-bio.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Meet Our Attorney', 'meet-our-attorney', 'publish', 'closed', 'closed', '', 'group_58f14ca4eeec8', '', '', '2017-04-14 22:37:28', '2017-04-14 22:37:28', '', 0, 'http://powers.com/?post_type=acf-field-group&#038;p=92', 0, 'acf-field-group', '', 0),
(93, 1, '2017-04-14 22:28:51', '2017-04-14 22:28:51', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:38:"Image must be 360px by 430px and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:355;s:10:"min_height";i:425;s:8:"min_size";s:0:"";s:9:"max_width";i:365;s:10:"max_height";i:435;s:8:"max_size";s:0:"";s:10:"mime_types";s:9:"jpg, jpeg";}', 'Meet Our Attorney Image', 'meet_our_attorney_image', 'publish', 'closed', 'closed', '', 'field_58f14cac18e74', '', '', '2017-04-14 22:28:51', '2017-04-14 22:28:51', '', 92, 'http://powers.com/?post_type=acf-field&p=93', 0, 'acf-field', '', 0),
(94, 1, '2017-04-14 22:31:31', '2017-04-14 22:31:31', '', 'profile-powers', '', 'inherit', 'open', 'closed', '', 'profile-powers', '', '', '2017-04-14 22:31:31', '2017-04-14 22:31:31', '', 43, 'http://powers.com/wp-content/uploads/2017/04/profile-powers.jpeg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2017-04-14 22:31:35', '2017-04-14 22:31:35', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-14 22:31:35', '2017-04-14 22:31:35', '', 43, 'http://powers.com/43-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2017-04-14 22:33:18', '2017-04-14 22:33:18', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Meet Attorney Title', 'meet_attorney_title', 'publish', 'closed', 'closed', '', 'field_58f14e1a7abb7', '', '', '2017-04-14 22:33:18', '2017-04-14 22:33:18', '', 92, 'http://powers.com/?post_type=acf-field&p=96', 1, 'acf-field', '', 0),
(97, 1, '2017-04-14 22:33:43', '2017-04-14 22:33:43', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-14 22:33:43', '2017-04-14 22:33:43', '', 43, 'http://powers.com/43-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2017-04-14 22:34:23', '2017-04-14 22:34:23', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Meet Attorney Quote', 'meet_attorney_quote', 'publish', 'closed', 'closed', '', 'field_58f14e5735c85', '', '', '2017-04-14 22:34:23', '2017-04-14 22:34:23', '', 92, 'http://powers.com/?post_type=acf-field&p=98', 2, 'acf-field', '', 0),
(99, 1, '2017-04-14 22:35:55', '2017-04-14 22:35:55', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-14 22:35:55', '2017-04-14 22:35:55', '', 43, 'http://powers.com/43-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2017-04-14 22:37:27', '2017-04-14 22:37:27', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Column 1', 'column_1', 'publish', 'closed', 'closed', '', 'field_58f14f07db597', '', '', '2017-04-14 22:37:27', '2017-04-14 22:37:27', '', 92, 'http://powers.com/?post_type=acf-field&p=100', 3, 'acf-field', '', 0),
(101, 1, '2017-04-14 22:37:27', '2017-04-14 22:37:27', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Column 2', 'column_2', 'publish', 'closed', 'closed', '', 'field_58f14f1edb598', '', '', '2017-04-14 22:37:27', '2017-04-14 22:37:27', '', 92, 'http://powers.com/?post_type=acf-field&p=101', 4, 'acf-field', '', 0),
(102, 1, '2017-04-14 22:37:53', '2017-04-14 22:37:53', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-14 22:37:53', '2017-04-14 22:37:53', '', 43, 'http://powers.com/43-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2017-04-14 22:39:01', '2017-04-14 22:39:01', '', 'Meet Our Attorney', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2017-04-14 22:39:01', '2017-04-14 22:39:01', '', 43, 'http://powers.com/43-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2017-04-14 22:42:16', '2017-04-14 22:42:16', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:20:"page-videocenter.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Video Center', 'video-center', 'publish', 'closed', 'closed', '', 'group_58f14fe537d7f', '', '', '2017-04-14 22:42:50', '2017-04-14 22:42:50', '', 0, 'http://powers.com/?post_type=acf-field-group&#038;p=104', 0, 'acf-field-group', '', 0),
(105, 1, '2017-04-14 22:42:16', '2017-04-14 22:42:16', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:9:"Add Video";}', 'Video', 'video', 'publish', 'closed', 'closed', '', 'field_58f14feb1181c', '', '', '2017-04-14 22:42:16', '2017-04-14 22:42:16', '', 104, 'http://powers.com/?post_type=acf-field&p=105', 0, 'acf-field', '', 0),
(106, 1, '2017-04-14 22:42:16', '2017-04-14 22:42:16', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:71:"Make sure the code is the pop up version and has a responsive thumbnail";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Wistis Code', 'wistis_code', 'publish', 'closed', 'closed', '', 'field_58f14ff71181d', '', '', '2017-04-14 22:42:50', '2017-04-14 22:42:50', '', 105, 'http://powers.com/?post_type=acf-field&#038;p=106', 0, 'acf-field', '', 0),
(107, 1, '2017-04-14 22:42:16', '2017-04-14 22:42:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Video Title', 'video_title', 'publish', 'closed', 'closed', '', 'field_58f150241181e', '', '', '2017-04-14 22:42:16', '2017-04-14 22:42:16', '', 105, 'http://powers.com/?post_type=acf-field&p=107', 1, 'acf-field', '', 0),
(108, 1, '2017-04-14 22:53:19', '2017-04-14 22:53:19', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2017-04-14 22:53:19', '2017-04-14 22:53:19', '', 67, 'http://powers.com/67-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2017-04-14 22:57:07', '2017-04-14 22:57:07', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2017-04-14 22:57:07', '2017-04-14 22:57:07', '', 67, 'http://powers.com/67-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2017-04-14 23:31:40', '2017-04-14 23:31:40', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Case Results', 'case-results', 'publish', 'closed', 'closed', '', 'group_58f155c0b52ff', '', '', '2017-04-14 23:31:40', '2017-04-14 23:31:40', '', 0, 'http://powers.com/?post_type=acf-field-group&#038;p=110', 0, 'acf-field-group', '', 0),
(111, 1, '2017-04-14 23:31:40', '2017-04-14 23:31:40', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Case Results', 'case_results', 'publish', 'closed', 'closed', '', 'field_58f155c8e9327', '', '', '2017-04-14 23:31:40', '2017-04-14 23:31:40', '', 110, 'http://powers.com/?post_type=acf-field&p=111', 0, 'acf-field', '', 0),
(112, 1, '2017-04-14 23:31:40', '2017-04-14 23:31:40', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_58f155e5e9328', '', '', '2017-04-14 23:31:40', '2017-04-14 23:31:40', '', 111, 'http://powers.com/?post_type=acf-field&p=112', 0, 'acf-field', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Request a Free Consultation', '2017-03-16 20:20:28', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8_unicode_ci,
  `entries_grid_meta` longtext COLLATE utf8_unicode_ci,
  `confirmations` longtext COLLATE utf8_unicode_ci,
  `notifications` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Request a Free Consultation","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"Full Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Full Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"phone","id":2,"label":"Number","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Number","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"textarea","id":4,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1}],"version":"2.1.3","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null}', '', '{"58caf38c80f92":{"id":"58caf38c80f92","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"58caf38c7ba90":{"id":"58caf38c7ba90","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-03-16 20:29:10', '::1', 22),
(2, 1, '2017-03-17 20:34:11', '::1', 40),
(3, 1, '2017-03-20 17:59:32', '::1', 16),
(4, 1, '2017-03-22 16:03:47', '::1', 117),
(5, 1, '2017-03-28 15:57:14', '::1', 122),
(6, 1, '2017-03-29 15:57:57', '::1', 61),
(7, 1, '2017-03-30 16:59:42', '::1', 113),
(8, 1, '2017-03-31 17:06:28', '::1', 48),
(9, 1, '2017-04-03 17:41:25', '::1', 183),
(10, 1, '2017-04-04 17:48:05', '::1', 160),
(11, 1, '2017-04-05 17:59:53', '::1', 193),
(12, 1, '2017-04-05 17:59:53', '::1', 1),
(13, 1, '2017-04-06 19:26:39', '::1', 129),
(14, 1, '2017-04-06 19:26:39', '::1', 1),
(15, 1, '2017-04-07 19:39:12', '::1', 71),
(16, 1, '2017-04-07 19:39:12', '::1', 1),
(17, 1, '2017-04-10 02:28:43', '::1', 242),
(18, 1, '2017-04-11 15:28:43', '::1', 142),
(19, 1, '2017-04-12 15:45:30', '::1', 526),
(20, 1, '2017-04-13 15:45:39', '::1', 674),
(21, 1, '2017-04-14 16:06:24', '::1', 213) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` longtext COLLATE utf8_unicode_ci NOT NULL,
  `submission` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `note_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(18, 2, 0),
(19, 2, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(25, 2, 0),
(38, 2, 0),
(41, 2, 0),
(42, 1, 0),
(45, 2, 0),
(48, 2, 0),
(52, 2, 0),
(54, 1, 0),
(54, 4, 0),
(54, 5, 0),
(58, 1, 0),
(58, 4, 0),
(58, 5, 0),
(60, 3, 0),
(60, 4, 0),
(69, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 12),
(3, 3, 'category', '', 0, 1),
(4, 4, 'category', '', 0, 3),
(5, 5, 'category', '', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Menu', 'top-menu', 0),
(3, 'Cat 1', 'cat-1', 0),
(4, 'Cat 2', 'cat-2', 0),
(5, 'Cat 3', 'cat-3', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'highrank'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"c1e6d946879c836569aadaba23b4d34dd459a5a7fabd9e96bf926743e99ca879";a:4:{s:10:"expiration";i:1492364578;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:52.0) Gecko/20100101 Firefox/52.0";s:5:"login";i:1492191778;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '49'),
(17, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(19, 1, 'nav_menu_recently_edited', '2'),
(20, 1, 'wp_user-settings', 'editor=html&libraryContent=browse&imgsize=full'),
(21, 1, 'wp_user-settings-time', '1492209468'),
(22, 1, 'wp_yoast_notifications', 'a:4:{i:0;a:2:{s:7:"message";s:307:"The configuration wizard helps you to easily configure your site to have the optimal SEO settings.<br/>We have detected that you have not finished this wizard yet, so we recommend you to <a href="http://powers.com/wp-admin/?page=wpseo_configurator">start the configuration wizard to configure Yoast SEO</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:31:"wpseo-dismiss-onboarding-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:766:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=4.6">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=4.6">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=4.6\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://powers.com/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:160:"Don\'t miss your crawl errors: <a href="http://powers.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:3;a:2:{s:7:"message";s:214:"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href="http://powers.com/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(23, 1, 'acf_user_settings', 'a:0:{}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'highrank', '$P$Bo.lLvMSec2FCrD0ElWlhVEzqWjRvj/', 'highrank', 'garrett@1point21interactive.com', '', '2017-03-08 22:29:02', '', 0, 'highrank') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

